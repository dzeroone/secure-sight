from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk
import json

# Define your Elasticsearch credentials
es_username = "elastic"
es_password = " zPgn6qJa"

# Connect to Elasticsearch with basic authentication
es = Elasticsearch(
    "http://localhost:9200",
    basic_auth=(es_username, es_password)  # Updated to use basic_auth
)

# Define the index name
index_name = "hello_world"

# Check if the index exists, and create it if it doesn’t
if not es.indices.exists(index=index_name):
    es.indices.create(index=index_name)

# Sample data to upload
sample_data = [
    {"_index": index_name, "_source": {"message": "Hello, World!", "status": "test"}},
    {"_index": index_name, "_source": {"message": "Hello from Elasticsearch!", "status": "demo"}}
]

# Upload data in bulk
try:
    bulk(es, sample_data)
    print(f"Data uploaded successfully to '{index_name}' index.")
except Exception as e:
    print(f"Error uploading data: {e}")

# Confirm by searching the data
try:
    response = es.search(index=index_name, body={"query": {"match_all": {}}})
    print("Uploaded Data:", json.dumps(response['hits']['hits'], indent=2))
except Exception as e:
    print(f"Error fetching data: {e}")
