export const DASHBOARD = "/dashboard";
export const WEEKLY_REPORT = DASHBOARD + "/weekly-report";
export const MONTHLY_REPORT = DASHBOARD + "/monthly-report";