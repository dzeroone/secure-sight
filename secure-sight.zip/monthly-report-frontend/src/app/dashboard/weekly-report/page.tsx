import React from "react";

const WeeklyReport = () => {
  return <div>WeeklyReport</div>;
};


export default WeeklyReport;