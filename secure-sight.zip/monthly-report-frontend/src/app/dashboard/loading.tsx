import Loader from "@@/components/Loader";

export default function Loading() {
  // You can add any UI inside Loading, including a Skeleton.
  return <Loader />;
}
