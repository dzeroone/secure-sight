export default function ReportTitleSmall({ children }) {
  return (
    <div className="h6">{children}</div>
  )
}