export default function ReportTitle({ children }) {
  return (
    <div className="h5">{children}</div>
  )
}