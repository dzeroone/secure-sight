import React from "react";
import { AccordionBody, AccordionHeader, AccordionItem } from "reactstrap";

const Accordion = ({}) => {
  return (
    <React.Fragment>
      <AccordionItem>
        <AccordionHeader> </AccordionHeader>
        <AccordionBody></AccordionBody>
      </AccordionItem>
    </React.Fragment>
  );
};

export default Accordion;
