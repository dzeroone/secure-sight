
const timedata = [
    { lable: "Last 5 Min Data", value: 5 * 60 * 1000 },
    { lable: "Last 10 Min Data", value: 10 * 60 * 1000 },
    { lable: "Last 30 Min Data", value: 30 * 60 * 1000 },
    { lable: "Last 60 Min Data", value: 60 * 60 * 1000 },
    { lable: "Last 5 Hour Data", value: 5 * 60 * 60 * 1000 },
    { lable: "Last 12 Hour Data", value: 12 * 60 * 60 * 1000 },
    { lable: "Last 1 Day Data", value: 1 * 24 * 60 * 60 * 1000 },
    { lable: "Last 5 Day Data", value: 5 * 24 * 60 * 60 * 1000 },
    { lable: "Last 10 Day Data", value: 10 * 24 * 60 * 60 * 1000 },
    { lable: "Last 30 Day Data", value: 30 * 24 * 60 * 60 * 1000 },
  ];

  export {timedata}